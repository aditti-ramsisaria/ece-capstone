#ifndef _NEUTON_TYPES_H_
#define _NEUTON_TYPES_H_

#include "neuton_common_types.h"
#include "dsp/neuton_dsp_types.h"

#endif /* _NEUTON_TYPES_H_ */